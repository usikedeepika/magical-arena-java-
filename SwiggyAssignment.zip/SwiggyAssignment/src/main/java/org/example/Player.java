package org.example;

import java.util.Random;

class Player {
    private int health;
    private int strength;
    private int attack;
    private Random random;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
        this.random = new Random();
    }

    public int getHealth() {
        return health;
    }

    public boolean isPlayerAlive() {   //to check whether the player is alive
                                 //the player is alive if his health value is greater than 0
        return health > 0;
    }

    public int attackerDiceValue() {
        return random.nextInt(6) + 1; // value of dice rolled by the attacker
    }

    public int defenderDiceValue() {
        return random.nextInt(6) + 1; // value of dice rolled by the defender
    }

    public int valueToAttack() {
        return this.attack * attackerDiceValue();
    }

    public int valueToDefend() {
        return this.strength * defenderDiceValue();
    }

    public void takeDamage(int damage) {
        this.health -= damage;
        if (this.health < 0) {
            this.health = 0; // health value should not be negative
        }
    }
}
