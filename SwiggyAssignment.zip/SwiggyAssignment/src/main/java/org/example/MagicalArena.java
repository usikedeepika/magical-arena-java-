package org.example;

class MagicalArena {
    private Player playerA;
    private Player playerB;

    public MagicalArena(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
    }

    public void startBattle() {

        while (playerA.isPlayerAlive() && playerB.isPlayerAlive()) {
            Player attacker;
            Player defender;

            if (playerA.getHealth() <=playerB.getHealth()) {
                attacker = playerA;
                defender = playerB;
            } else  {
                attacker = playerB;
                defender = playerA;
            }

            int attackValue = attacker.valueToAttack();
            int defenseValue = defender.valueToDefend();

            int damageToDefender = attackValue - defenseValue;
            if (damageToDefender > 0) {
                defender.takeDamage(damageToDefender);
            }
        }

        if (playerA.isPlayerAlive()) {
            System.out.println("Player A wins!");
        } else {
            System.out.println("Player B wins!");
        }
    }
}
