package org.example;


import static org.junit.Assert.assertFalse;

import org.junit.Test;

public class MagicalArenaTest {
    @Test
    public void testStartBattle() {
        Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);

        MagicalArena arena = new MagicalArena(playerA, playerB);
        arena.startBattle();
        assertFalse(playerA.isPlayerAlive() && playerB.isPlayerAlive()); // Either playerA or playerB should be dead after the fight
    }
}