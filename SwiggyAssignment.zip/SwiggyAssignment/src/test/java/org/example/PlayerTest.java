package org.example;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PlayerTest {

    @Test
    public void testAttackerDice() {
        Player player = new Player(50, 5, 10);
        int attackDice = player.attackerDiceValue();
        assertTrue("Attack roll should be between 1 and 6", attackDice >= 1 && attackDice <= 6);
    }

    @Test
    public void testDefenderDice() {
        Player player = new Player(100, 5, 10);
        int defenseDice = player.defenderDiceValue();
        assertTrue("Defense roll should be between 1 and 6", defenseDice >= 1 && defenseDice <= 6);
    }
}
